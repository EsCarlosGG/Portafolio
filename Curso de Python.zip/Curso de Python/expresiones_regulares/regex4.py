import re

email = "example@example.com"

pattern = "[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}"

#El "+" sirve como condicion, y nos dice que tiene que alver al menos 1 coincidencia
#si no, no devuelve


result = re.match(pattern, email)                                       #El .match busca si hay coincidencias

if result:
    print("Direccion de correo valida")
else:
    print("Direccion de correo invalida")