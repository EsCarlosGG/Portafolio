
def contar_calorias():
    #Le pedimos al usuario sus datos fisicos y personales
    genero = int(input("ingrese su genero:   1. Hombre  2. Mujer  :"))
    peso = int(input("ingrese su peso en kg: "))
    altura = int(input("ingrese su estaura en cm: "))
    edad = int(input("ingrese su edad: "))
    actividad = int(input('''Estilo de vida:
                      1. Sedentario
                      2. Ligeramente activo
                      3. Activo o Moderadamente Activo
                      4. Atleta de alto rendimiento
                      : '''))
    
    
    calorias_base = 0
    #utilizamos if para que filtre sus datos por genero, peso, altura y edad
    if genero == 1:        #calculo para las caloras base
        calorias_base = (66.47 + (13.75 * peso) + (5 * altura) - (6.74 * edad))
        if actividad == 1:
            calorias_totales = calorias_base * 1.3
        elif actividad == 2:
            calorias_totales = calorias_base * 1.5
        elif actividad == 3:
            calorias_totales = calorias_base * 1.6
        elif actividad == 4:
            calorias_totales = calorias_base * 1.9
            #el elif de arriba calcula las calorias totales en base a su estilo de vida
                   
    elif genero == 2:
        calorias_base = (655.1 + (9.56 * peso) + (1.85 * altura) - (4.68 * edad))
        if actividad == 1:
            calorias_totales = calorias_base * 1.3
        elif actividad == 2:
            calorias_totales = calorias_base * 1.5
        elif actividad == 3:
            calorias_totales = calorias_base * 1.6
        elif actividad == 4:
            calorias_totales = calorias_base * 1.9
            
       
    print(f"Tus calorias diarias son: {calorias_totales * 10 // 10:,} kcal")
    
contar_calorias()