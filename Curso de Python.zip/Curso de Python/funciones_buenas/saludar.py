def saludar(name):
    return f"Hola {name}! Espero que te la estes pasando piola wacho."

def saludar_raro(name):
    return f"K pasa {name}! Espero te secuestre un alien pa y conquistes Marte."

print(__name__)