def decorador(funcion):
    def funcion_modificada():                            #Se crea una funcion
        print("Antes de llamar a la funcion")            #Aqui se ejecuta un codigo antes
        funcion()                                        #Aqui ejecuta la funcion que le pasamos como parametro
        print("Despues de llamar a la funcion")          #Ejecuta un codigo despues
    return funcion_modificada                            #aqui nos devuelve la funcion que creo

# def saludo():
#     print("Hola soy Carlos")
    
# saludo_modificado = decorador(saludo)
# saludo_modificado()                                     #Practicamente aqui la variable la hacemos una funcion



#/////////////////  FORMA OPTIMA  ////////////////////

@decorador      #Palabra reservada, usamos @
def saludo():
    print("Hola soy Carlos")              #Creamos la funcion sobre el decorador
    
saludo()                                  #Esta es ahora la funcion ya modificada