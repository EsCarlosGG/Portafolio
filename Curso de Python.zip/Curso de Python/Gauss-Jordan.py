matriz_base = [
    [1, 2, 3],
    [2, 5, 3],
    [1, 0, 8]
    ]
matriz_identidad = [
    [1, 0, 0],
    [0, 1, 0],
    [0, 0, 1]
    ]

matriz_junta = [matriz_base]
