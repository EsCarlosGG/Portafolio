#creando las listas
frutas = ["banana","manzana","ciruela","naranja","uvas","sandia","melon"]
cadena = "Hola Soy Carlos"
numeros = [3,5,7,18]

#evitando que se coma una manzana con la sentencia continue
for fruta in frutas:
    if fruta == "ciruela":
        continue
    print(f"Me voy a comer una: {fruta}")

#evitar que el bucle siga ejecutandose (el esle no se ejecuta tampoco)
for fruta in frutas:
    print(f"Me voy a comer una: {fruta}")
    if fruta == "naranja":
        break
else:
    print("bucle terminado")
    
#recorrer una cadena de texto
for letra in cadena:
    print(letra)
    
#for en una sola linea de codigo (duplicamos los numeros)
numeros_duplicados = [x * 2 for x in numeros]
print(numeros_duplicados)

