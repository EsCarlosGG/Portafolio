diccionario = {
    "nombre" : 'carlos',
    "apellido" : 'garnica',
    "edad" : 18
}

#nos devuelve un objeto dict_item
claves = diccionario.keys()

#obteniendo un elemento con get() (si no encuentra nada el programa continua)
valor_de_asdasd = diccionario.get("asdasd")
print("continua el program")

#eliminando todo del diccionario
#diccionario.clear()

#eliminando un elemento del diccionario
diccionario.pop("nombre")

#obteniendo un elemento dict_items iterable
diccionario_iterable = diccionario.items()

print(claves)

