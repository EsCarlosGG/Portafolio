

edad = 17

if edad >= 18:
    print("Puedes pasar")
    
else:
    print("Vete a la mierda")