#pedfirle un dato al usuario
nombre = input("Ingrese un nombre: ")    #Siempre lo devuelve en texto (string) aunque te devuelva un numero

#mostrando el dato
print(f'el nombre es: {nombre}')