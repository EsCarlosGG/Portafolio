
# Crando una lista (se pueden modificar)
lista = ["Carlos Garnica", "Carlos",True, 1.80]

# Creando una dupla
tupla = ("Carlos Garnica", "Carlos",True, 1.80) #la dupla No se puede modificar

#print(lista[1])


# Esto es valido
lista[3] = "Mario"
#print(lista[3])



# Esto no es valido:

# tupla[3] = "Mario"
# print(tupla[3])



#Creando un conjunto (set) (no se accede a elementos por indice, no alamacena datos duplicados, no tienen un orden)

conjunto = {"Carlos Garnica", "Carlos",True, 1.80}

#print(conjunto[3]) -> no se puede acceder al elemento

#print(conjunto)


#Creando un diccionario (dict) (la estructura es key : value y separamos con comas)

diccionario = {
    'nombre' : "Carlos",
    'pais' : "Mexico",
    'altura' : 1.81,
    'dato_duplicado' : "Carlos"
}

    #Key ^    #Value ^


 
                    #Key
print(diccionario['altura'])
