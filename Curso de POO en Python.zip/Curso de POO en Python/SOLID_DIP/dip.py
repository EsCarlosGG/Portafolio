# class Diccionario:
#     def verificar_palabra(self, palabra):
#         #Logica para verificar palabras
#         pass
    
# class CorrectorOrtografico:                                #Todos los correctores ortograficos tienen un Diccionario como parte de sus atributos
#     def __init__(self):
#         self.diccionario = Diccionario()                   #Tendra un objeto de Diccionario, con toda su logica
        
#     def corregir_texto(self, texto):
#         #Usamos el diccioario para corregir el texto       #Va a usar el self.diccionario (con toda su logica de la clase para verificarla) y va a hacer su tarea
#         pass
    


#Este codigo viola el principio DIP ya que la funcion corregir_texto y la clase CorrectorOrtgrafico dependen fuertemente de la clase diccionario


from abc import ABC, abstractmethod

class VerificadorOrtografico(ABC):
    @abstractmethod
    def verificar_palabra(self, palabra):
        pass
    
class Diccionario(VerificadorOrtografico):
    def verificar_palabra(self, palabra):
        #Logica para verificar palabras si esta en el diccionario        #3.- Este es el verificador
        pass                                                                 #Que se encarga de verificarlo y de poder corregir el texto



class ServicioOnline(VerificadorOrtografico):
    def verificar_palabra(self, palabra):
        #Logica para verificar palabras si esta en el servicio web
        pass


 
class CorrectorOrtografico:                                              #1.- Ahora CorrectorOrtografico esta dependiendo de la abstraccion del Verificador
    def __init__(self, verificador):
        self.verificador = verificador
        
    def corregir_texto(self, texto):
        #Usamos el verificador para corregir texto                       #2.- Abstraccion de Verificador
        pass
    
    
    
#Es decir, como VerificadorOrtografico es una clase abstracta tenemos todos los metodos que necesitamos ahi mismo, si tiene mas metdos, como por ejemplo:
#buscar_similares() o corregir_ortografia() o agregar_acentos() podemos aquedarno tranquilos de que podemos seguir usando los mismos metodos que tenga el verificador,
#porque al ser una subclase tendria que poder hacer todo lo que hace la clase base (Principio de sustitucion de Liskov)



# = = = = = = = = = = = = = = = Depende de un interfaz, no de un metodo especifico = = = = = = = = = = = = = = =