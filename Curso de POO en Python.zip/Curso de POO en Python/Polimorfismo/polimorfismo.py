class Gato():
    def Sonido(self):
        return "Miau"

class Perro():
    def Sonido(self):
        return "Guau"

def hacer_sonido(animal):
    print(animal.Sonido())
    
gato = Gato()
perro = Perro()

hacer_sonido(perro)  #Polimorfismo de Funcion
                     #Cambia el parametro. Aqui podemos utilizar diferentes objetos o clases como argumento de la funcion, pero la funcion es la misma
                     #El mismo metodo funciona diferente para diferentes argumentos
                     
print(perro.Sonido())  #Aqui estamos llamando a perro y ejecutamos su metodo "Sonido()"
print(gato.Sonido())   #Si cambiamos a gato es lo mismo, es polimorfismo
                       #El mismo metodo funciona diferente para diferentes objetos