
#numero_fibonacci = int(input("Ingrese el numero para Fibonacci: "))

lista_fibonacci = [0]
a = 0
b = 1

#for num in range(numero_fibonacci):
 #   if b > num: lista_fibonacci
 #   else:
 #       lista_fibonacci.append(b)
 #       a,b = b,a+b
        


n = int(input("Ingrese un numero para factorial: "))

factorial = 1
for i in range(1, n+1):
   factorial *= i
print(factorial)