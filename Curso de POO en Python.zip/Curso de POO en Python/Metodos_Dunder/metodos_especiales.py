class Persona:
    def __init__(self, nombre, edad):           # "__init__" Lo usamos como contructor
        self.nombre = nombre
        self.edad = edad
        
    
    def __str__(self):                                                      #Nos devuelve una representacion del objeto en una cadena de texto
        return f"Persona(nombre={self.nombre}, edad={self.edad})"           #Con esto le explicamos como queremos que nos devuelve un dato, pero en forma de texto
    
    
    def __repr__(self):
        return f'Persona("{self.nombre}", {self.edad})'     
    
carlos = Persona("Carlos",19)

repre = repr(carlos)                      #Con esto obtenemos una representacion del objeto, para despues reconstruirlo
resultado = eval(repre)                   #Y aqui reconstruye el objeto, pero ahora este es el objeto

print(resultado.nombre)