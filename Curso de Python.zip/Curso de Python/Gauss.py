def create_identity_matrix(size):
    """Crea una matriz identidad de tamaño 'size'."""
    identity_matrix = []
    for i in range(size):
        row = [0] * size
        row[i] = 1
        identity_matrix.append(row)
    return identity_matrix

def print_matrix(matrix):
    """Imprime la matriz de forma legible."""
    for row in matrix:
        print(row)
    print()

def gauss_jordan(matrix, vector):
    n = len(matrix)
    # Crear la matriz aumentada combinando la matriz de coeficientes con la identidad
    augmented_matrix = [matrix[i] + create_identity_matrix(n)[i] for i in range(n)]
    
    print("Matriz aumentada inicial:")
    print_matrix(augmented_matrix)
    
    # Realizar la eliminación Gauss-Jordan
    for i in range(n):
        # Encontrar el pivote y normalizar la fila
        pivot = augmented_matrix[i][i]
        if pivot == 0:
            # Intercambiar filas si el pivote es 0
            for k in range(i+1, n):
                if augmented_matrix[k][i] != 0:
                    augmented_matrix[i], augmented_matrix[k] = augmented_matrix[k], augmented_matrix[i]
                    pivot = augmented_matrix[i][i]
                    break
        # Normalizar la fila dividiéndola por el pivote
        augmented_matrix[i] = [element / pivot for element in augmented_matrix[i]]
        
        # Eliminar los elementos en la columna del pivote para las otras filas
        for j in range(n):
            if i != j:
                ratio = augmented_matrix[j][i]
                augmented_matrix[j] = [augmented_matrix[j][k] - ratio * augmented_matrix[i][k] for k in range(len(augmented_matrix[j]))]
        
        print(f"Después de procesar fila {i + 1}:")
        print_matrix(augmented_matrix)
    
    # Extraer la matriz inversa de la parte derecha de la matriz aumentada
    inverse_matrix = [row[n:] for row in augmented_matrix]
    
    # Multiplicar la matriz inversa por el vector de términos independientes para obtener la solución
    solution = [sum(inverse_matrix[i][j] * vector[j] for j in range(n)) for i in range(n)]
    
    return inverse_matrix, solution

# Ejemplo de uso
matrix = [
    [1, 2, 3],
    [2, 5, 3],
    [1, 0, 8]
]
vector = [8, -11, -3]

inverse_matrix, solution = gauss_jordan(matrix, vector)

print("Matriz inversa:")
print_matrix(inverse_matrix)

print("La solución es:", solution)