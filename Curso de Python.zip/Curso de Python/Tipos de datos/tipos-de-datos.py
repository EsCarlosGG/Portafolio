

"string"                   #dato tipo texto que solo se usa en una sola linea de codigo con solo unas comillas dobles




""""aasdasasda
asdasdasdasdasdasd          
asdasdasdasdasd"""          #sting que se puede usar en varias lineas de codiggo con triples comillas




40
                                # tipo int
                        
40.242



True
                                # tipo Booleano
False 