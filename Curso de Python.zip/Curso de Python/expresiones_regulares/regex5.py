import re

text = "Este es un ejemplo de una pagina web: https://www.example.com y tambien podemos visitar: https://example.org"

pattern = "https?://[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}"

#Si encuentras https (puede ser HTTPS o HTTP), sigue, si no, no pasa nada padrino
#El ? es: encuentra una coincidencia o ninguna (en este caso, esta diciendo que la "s" en "https" es opcional)



result = re.findall(pattern, text)


print(result)