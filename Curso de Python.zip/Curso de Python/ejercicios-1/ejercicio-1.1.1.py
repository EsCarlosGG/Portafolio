
#promedio de duracion

otros_cursos_min = 2.5
otros_cursos_max = 7
otros_cursos_promed = 4
dalto_curso = 1.5

#Duracion de crudos
crudo_proemdio = 5
crudo_dalto = 3.5

#Diferencias de duracion
diferencia_con_min = 100 - round(dalto_curso * 100 / otros_cursos_min , 1)
diferencia_con_max = 100 - round(dalto_curso * 100 / otros_cursos_max , 1)
diferencia_con_promedio = 100 - round(dalto_curso * 100 / otros_cursos_promed , 1)

#Calculando el procentaje de tiempo vacio removido
tiempo_vacio_promedio = 100 - round(otros_cursos_promed * 100 / crudo_proemdio , 2)
tiempo_vacio_dalto = 100 - round(dalto_curso * 100 / crudo_dalto , 1)


#Mostrando las diferencias de duracion (Ejercicio A)
print("-----------------------------------------")
print("El curso de dalto dura")
print(f' - Un {diferencia_con_min}% menos que el mas rapido')
print(f' - Un {diferencia_con_max}% menos que el mas lento')
print(f' - Un {diferencia_con_promedio}% menos que el promedio')

print("-----------------------------------------")

#Mostrando la cantidad de espacion vacios que se remueven (Ejercicio B)
print(f'Un curso promedio elimina un {tiempo_vacio_promedio}% de tiempo vacio')
print(f'Este curso elimino el {tiempo_vacio_dalto}% de tiempo vacio')

print("-----------------------------------------")

#Mostrando diferencias si los cursos duraran 10 horas
print(f'Ver 10 horas de este curso equivale a ver {otros_cursos_promed * 100 // dalto_curso / 10} horas de otros cursos')
print(f'Ver 10 horas de otros cursos equivale a ver {dalto_curso * 100 // otros_cursos_promed / 10} horas de este cursos')
print("-----------------------------------------")