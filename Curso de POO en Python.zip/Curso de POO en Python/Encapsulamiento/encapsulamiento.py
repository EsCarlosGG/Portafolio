class MiClase:
    def __init__(self):
        self.__atributo_privado = "Valor"        #Con el " __ " despues del self. (en este caso) lo vuelve un atributo muy privado (pero si se accede)
                                                 #Con solo 1 " _ " lo hace privado simple, pero que si podemos acceder si queremos
    
    def __hablar(self):
        print("hola wacho")
                                                
                                                
objeto = MiClase()
print(objeto.__hablar())