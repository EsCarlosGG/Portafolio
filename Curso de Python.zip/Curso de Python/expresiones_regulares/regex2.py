import re

# La cadena en la que se buscaran los parametros
text = "La fecha es 08/08/2024 y el telefono es +1-555-555-5555"

# El patron a buscar
pattern = r"\d{2}/\d{2}/\d{4}"

# El texto con el que se remplazara el patron
replacement = "Fecha Oculta"

#Reemplazar todas las apariciones del patron en la cadena de texto
new_text = re.sub(pattern, replacement, text)                                      #"re.sub()" Encuentra la cadena y hace un remplazo

#Primero agarra el texto
#Despues busca el patron
#Y si encuentra una coincidencia, la remplaza por "Fecha oculta"


 
# Imprimir el resultado
print("Texto modificado: ", new_text)