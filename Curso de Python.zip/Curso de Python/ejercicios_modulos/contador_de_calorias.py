def Contador_calorias(genero, peso, altura, edad, actividad):
    calorias_base = 0
    if genero == 1:
        calorias_base = (66.47 + (13.75 * peso) + (5 * altura) - (6.74 * edad))
        if actividad == 1:
            calorias_totales = calorias_base * 1.3
        elif actividad == 2:
            calorias_totales = calorias_base * 1.5
        elif actividad == 3:
            calorias_totales = calorias_base * 1.6
        elif actividad == 4:
            calorias_totales = calorias_base * 1.9
    
    elif genero == 2:
        calorias_base = (655.1 + (9.56 * peso) + (1.85 * altura) - (4.68 * edad))
        if actividad == 1:
            calorias_totales = calorias_base * 1.3
        elif actividad == 2:
            calorias_totales = calorias_base * 1.5
        elif actividad == 3:
            calorias_totales = calorias_base * 1.6
        elif actividad == 4:
            calorias_totales = calorias_base * 1.9
    
    return f"""
          Tus calorias diarias son: {calorias_totales * 10 // 10:,} kcal
          """