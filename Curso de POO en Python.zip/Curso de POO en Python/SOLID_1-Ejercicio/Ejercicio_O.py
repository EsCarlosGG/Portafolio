class Figuras:
    def area(self):
        raise NotImplementedError("Las otras clases deben de tener este metodo")

class Circulo(Figuras):
    def __init__(self, radio):
        self.radio = radio
        
    def area(self):
        return 3.1416 *  (self.radio ** 2)
    
class Rectangulo(Figuras):
    def __init__(self, lado_1, lado_2):
        self.lado_1 = lado_1
        self.lado_2 = lado_2
        
    def area(self):
        return self.lado_1 * self.lado_2

class TrianguloEquilatero(Figuras):
    def __init__(self, base, altura):
        self.base = base
        self.altura = altura
        
    def area(self):
        return (self.base * self.altura) / 2
