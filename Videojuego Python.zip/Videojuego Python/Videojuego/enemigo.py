import pygame
import time
import random

class Enemigo:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.ancho = 75
        self.alto = 75
        self.velocidad = 5
        self.color = "purple"
        self.rect = pygame.Rect(self.x, self.y, self.ancho,self.alto)              #"sf.rect" es la forma que tiene pygame de crear objetos y definir su ancho, largo, coordenadas, dimensiones, etc...
        self.last_move_time = pygame.time.get_ticks()                              #Guarda el tiempo del utlimo movimiento
        self.vida = 3
        self.imagen = pygame.image.load("Videojuego/enemigo.png")
        self.imagen = pygame.transform.scale(self.imagen, (self.ancho, self.alto))
        
    def dibujar(self, ventana):
        self.rect = pygame.Rect(self.x, self.y, self.ancho,self.alto)              #cada vez que llamemos a la funcion "dibujar", tambien tenemos que ponerle este atributo del constructor(self.rect)
        #pygame.draw.rect(ventana, self.color, self.rect)                           #ya que es una manera de actualizar sus cordenadas
        ventana.blit(self.imagen, (self.x, self.y))   
        
    def movimiento(self):
        self.y += self.velocidad                                                   #Aqui le damos movimiento, usamos el eje y, va en caida
    