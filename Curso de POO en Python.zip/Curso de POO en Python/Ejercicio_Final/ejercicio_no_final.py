from textblob import TextBlob 

class AnalizadorDeSentimientos:
    def analizar_Sentimientos(self, texto):
        analisis = TextBlob(texto)                        #Aqui le pasamos el texto
        if analisis.sentiment.polarity > 0:               #"sentiment" es una propiedad de del objeto analisis que a su vez tiene otra propiedad que es "polarity"
            return "positivo"
        elif analisis.sentiment.polarity == 0:
            return "neutral"
        else:
            return "negativo"
        
analizador = AnalizadorDeSentimientos()
resultado = analizador.analizar_Sentimientos("Hello i feel happy")
print(resultado)