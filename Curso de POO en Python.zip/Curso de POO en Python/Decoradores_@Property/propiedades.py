class Persona:
    def __init__(self, nombre, edad):
        self._nombre = nombre
        self._edad = edad
        
    @property
    def nombre(self):                    #con esto podemos eliminamar los parentesis de la funcion, cuando la llamamos ya no es necesario especificar que es un getter
        return self._nombre              # ya no es necesario especificar que es un getter
                                         #con este decorador, accedemos a una propiedad
    
    
    @nombre.setter                       #De esta forma podemos crear el mismo metodo. Con este decorador podemos modificar la propiedad, por el .setter
    def nombre(self, new_nombre):
        self._nombre = new_nombre
    
    @nombre.deleter
    def nombre(self):                    #con esto podemos eliminamar ulgun metodo o propiedad con .deleter
        del self._nombre  
    


carlos = Persona("Carlos",19)

nombre = carlos.nombre                   #Aqui ya no es necesario poner parentesis, ya que lo convierte en una "propiedad"
print(nombre)

# carlos.nombre = "Pablo"                #Si quisieramos modificarlo, no se puede modificar por que es un getter

carlos.nombre = "Pablo"                  #Con esto ahora si podemos modificarlo ya que es un setter
                                         #Tambien estamos encapsulando

nombre = carlos.nombre
print(nombre)



del carlos.nombre                        #Aqui lo eliminamos con el "del"
                                        #Pd: si queremos acceder a la propiedad luego, nos tira un Error

