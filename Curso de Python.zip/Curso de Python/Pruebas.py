
# Matrices base
r1 = [1, 2, 3]
r2 = [2, 5, 3]
r3 = [1, 0, 8]

# Matrices identidad
ir1 = [1, 0, 0]
ir2 = [0, 1, 0]
ir3 = [0, 0, 1]

# Matrices inversa
inversa_r1 = [0] * len(r1)
inversa_r2 = [0] * len(r2)
inversa_r3 = [0] * len(r3)

# Matrices 0 resultado
ir1_resultado = [0] * len(ir1)
ir2_resultado = [0] * len(ir2)
ir3_resultado = [0] * len(ir3)

# Función para realizar la eliminación de filas
def gauss_jordan(r1, r2, r3, ir1, ir2, ir3):
    # Pivoteo en la primera fila
    pivot = r1[0]
    if pivot != 1:
        factor = 1 / pivot
        r1 = [x * factor for x in r1]
        ir1 = [x * factor for x in ir1]

    # Eliminación de los elementos en la primera columna de las otras filas
    for i, row in enumerate([r2, r3]):
        factor = row[0]
        if factor != 0:
            row = [row[j] - factor * r1[j] for j in range(len(row))]
            if i == 0:
                r2 = row
            else:
                r3 = row
            ir = ir2 if i == 0 else ir3
            ir = [ir[j] - factor * ir1[j] for j in range(len(ir))]

    # Pivoteo en la segunda fila
    pivot = r2[1]
    if pivot != 1:
        factor = 1 / pivot
        r2 = [x * factor for x in r2]
        ir2 = [x * factor for x in ir2]

    # Eliminación de los elementos en la segunda columna de las otras filas
    for i, row in enumerate([r1, r3]):
        factor = row[1]
        if factor != 0:
            row = [row[j] - factor * r2[j] for j in range(len(row))]
            if i == 0:
                r1 = row
            else:
                r3 = row
            ir = ir1 if i == 0 else ir3
            ir = [ir[j] - factor * ir2[j] for j in range(len(ir))]

    # Pivoteo en la tercera fila
    pivot = r3[2]
    if pivot != 1:
        factor = 1 / pivot
        r3 = [x * factor for x in r3]
        ir3 = [x * factor for x in ir3]

    # Eliminación de los elementos en la tercera columna de las otras filas
    for i, row in enumerate([r1, r2]):
        factor = row[2]
        if factor != 0:
            row = [row[j] - factor * r3[j] for j in range(len(row))]
            if i == 0:
                r1 = row
            else:
                r2 = row
            ir = ir1 if i == 0 else ir2
            ir = [ir[j] - factor * ir3[j] for j in range(len(ir))]

    # Almacenar resultados
    inversa_r1[:] = ir1
    inversa_r2[:] = ir2
    inversa_r3[:] = ir3

    ir1_resultado[:] = r1
    ir2_resultado[:] = r2
    ir3_resultado[:] = r3

# Ejecutar la función
gauss_jordan(r1, r2, r3, ir1, ir2, ir3)

# Mostrar resultados
print("Inversa de r1:", inversa_r1)
print("Inversa de r2:", inversa_r2)
print("Inversa de r3:", inversa_r3)
print("Resultado de ir1:", ir1_resultado)
print("Resultado de ir2:", ir2_resultado)
print("Resultado de ir3:", ir3_resultado)
