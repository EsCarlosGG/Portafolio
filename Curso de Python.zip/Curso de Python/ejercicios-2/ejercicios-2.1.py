
#falto el profe y los pibes van a armar la clase.

#funcion para obtener al asistente y al profesor agun la edad.
def obtener_companeros(cantidad_de_companeros):
    
    #creando la lista con los companeros
    companeros = []
    
    #ejecutando un for para pedir informacion de cada companero
    for i in range(cantidad_de_companeros):
        nombre = input("Ingrese el nombre del companero: ")
        edad = int(input("Ingrese la edad del companero: "))
        companero = (nombre, edad)
        
        #agregando la informacion a la lista
        companeros.append(companero)
        
    #ordenandolos de menor a mayor segun su edad    
    companeros.sort(key=lambda x:x[1])
    
    #companeros[x] devuelve una tupla con (nombre, edad) y despues accedemos al nombre
    #para definir al asistente y al profesor.
    asistente = companeros[0][0]
    profesor = companeros[-1][0]
    
    #retornamos una tupla
    return asistente,profesor

#desempaquetamos lo que nos retorna la funcion
asistente,profesor = obtener_companeros(5)

print(f"El profesor es: {profesor} y su asistente es: {asistente}")
    
