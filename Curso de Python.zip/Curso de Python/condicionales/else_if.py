ingreso_mensual = 81000


if ingreso_mensual > 10000:
    print("estas bien economicamente en cualquier parte del mundo")
    
elif ingreso_mensual > 1000:
    print("estas bien en latam")
    
else:
    print("eres pobre")

    
    
gasto_mensual = 80000

if ingreso_mensual > 10000:
    if ingreso_mensual - gasto_mensual < 0:
        print("estas en deficit")
    elif ingreso_mensual - gasto_mensual > 3000:
            print("algo bien") 
    else:
        print("gastas mucho wey, a ver si la haces") 
    
elif ingreso_mensual > 1000:
    print("estas bien en latam")
    
else:
    print("eres pobre")