
#creando tuplas con tuple()
tupla = tuple(["dato1","dato2"])

#creando una tupla sin parentesis de multiples datos
tupla = "dato1","dato2"

#creando una tupla sin parentesis de un solo dato
tupla = "dato", 

print(tupla)