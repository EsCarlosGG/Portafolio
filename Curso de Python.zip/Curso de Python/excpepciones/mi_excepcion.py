
#Creando mi propia excpecion personalizada
class MiExcpecion(Exception):
    def __init__(self,err):
        print(f"Impresionante, cometiste el siguiente error: {err}")
        
#Lanzando mi propia excepcion
#raise MiExcpecion("Persona poco culta")


#Manejandola
try:
    raise MiExcpecion("Persona poco culta")
except:
    print("Como vas a cometer ese error?")