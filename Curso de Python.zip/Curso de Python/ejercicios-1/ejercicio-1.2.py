#Le pedimos al usuario que nos diga una frase (o varias)
frase = input("Dime una frase y calculo cuanto tardartias si tuvieras que decirla: ")

#Creamos una lista con todas las palabras de la frase (se sepoaran cada vez que hata un espacio en blanco)
palabras_sparadas = frase.split(" ")

#Usamos len() para ver la cantidad de elementos que hay en la lista
cantidad_de_palabras = len(palabras_sparadas)

#En caso de que tarde mas de un minuto en decirlo, le decimos que pare un poco
if cantidad_de_palabras > 120:
    print("Calmate pa, no te pedi un testamento")
    
#Calculamos cuanto tardaria en decir las palabras y se lo decimos
print(f'Dijiste {cantidad_de_palabras} palabras, y tardarias {cantidad_de_palabras/2} segundos en decirlo')
print(f'Carlos lo diria en {cantidad_de_palabras * 100 // 2 * 1.3 / 100} segundos')