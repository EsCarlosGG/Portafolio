#usando open para abrir un archivo (con una codificacion universal usamos (encoding ="UTF-8"))
archivo = open("archivos\\texto_de_carlos.txt")

#leer archivo comopleto
#archivo = archivo.read()

#leer una sola linea
#linea = archivo.readline()

#leer linea por linea
lineas = archivo.readlines()

#cerrar el archivo
archivo.close()

print(lineas)