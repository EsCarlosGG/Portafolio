#creando diccionarios con dict()
diccionario = dict(nombre = "Carlos", apellido = "Garnica")

#las listas no pueden ser claves yusamos frozenset para meter conjuntos
diccionario = {frozenset(["Carlos", "Pro"]) : "juasjuas"}

#crando diccionarios con fromkeys() valor por defecto: none
diccionario = dict.fromkeys(["nombre","apellido"])

#crando diccionarios con fromkeys() cambiando el valor por defecto a "edad"
diccionario = dict.fromkeys(["nombre","apellido"],"edad")


print(diccionario["nombre"])