class Notificador:
    def __init__(self, usuario, mensaje):
        self.usuario = usuario
        self.mensaje = mensaje
        
    def Notificar(self):               #Con esto estamos obligando al desarrollador que tiene que crear la clase "notificar()"
        raise NotImplementedError      #Si no, le saltara Error por que no se implemento
    

class NotificadorEmail(Notificador):
    def Notificar(self):
        print(f"Enviando mensaje por Mail a {self.usuario.email}")
        
class NotificadorSMS(Notificador):
    def Notificar(self):
        print(f"Enviando SMS a {self.usuario.sms}")
        
class NotificadorWhatsApp(Notificador):
    def Notificar(self):
        print(f"Enviando WhatsApp a {self.usuario.whatsapp}")
        
class NotificadorIntagram(Notificador):
    def Notificar(self):
        print(f"Enviando mensaje por Instagram a {self.usuario.ig}")