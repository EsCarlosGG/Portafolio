def saludar_raro(name):
    return f"K pasa {name}! Espero te secuestre un alien pa y conquistes Marte."
