num1 = 3
num2 = 4.4


#Convierte el int a float para hacer la operacion
resultado = num1 + num2

print(resultado)
print(type(resultado))

#Se adapta a los tipo de datos