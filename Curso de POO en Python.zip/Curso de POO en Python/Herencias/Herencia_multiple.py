class Persona:                                                #Clase Padre
    def __init__(self,nombre,edad,nacionalidad):
        self.nombre = nombre
        self.edad = edad
        self.nacionalidad = nacionalidad
    
    def hablar(self):
        print(f"Hola, soy {self.nombre} y estoy hablando")

class Artista:                                                 #Clase Padre
    def __init__(self,habilidad):
        self.habilidad = habilidad
    
    def mostrar_habildiad(self):
        return f"Mi hablidad es: {self.habilidad}"


class EmpleadoArtista(Persona,Artista):                                               #Clase hija
    def __init__(self,nombre,edad,nacionalidad,habilidad,salario,empresa):
        Persona.__init__(self,nombre,edad,nacionalidad)                     #Se llama a la clase padre y a su propio __init__(de la padre) para hacer el constructor
        Artista.__init__(self,habilidad)                                    #y asi igualar sus variables con la clase hija (instanciacion)
        self.salario = salario
        self.empresa = empresa
    
    def presentarse(self):
        print(f"Hola, soy: {self.nombre}, {super().mostrar_habildiad()} y trabajo en {self.empresa}")
        
        
        
humano = EmpleadoArtista("Maximiliano",24,"Andorrano","Pianista",5000,"Banamex")

herencia = issubclass(EmpleadoArtista,Persona)  #Se utliza para saber si una clase es hija de una clase padre
instancia = isinstance(humano,Persona)          #Se utliza para saber si un objeto es una instanciacion de una clase

print(instancia)