
class TanqueDeCombustible:                            #Primero creamos un tanque de combustible
    def __init__(self):
        self.combustible = 100                        #Tiene una propiedad estatica que su valor es cien, predeterminadamente siempre que se cree un tanque
        
    def agregar_combustible(self, cantidad):          #Creamos un metodo para agregar combustible
        self.combustible += cantidad
        
    def obtener_combustible(self):                    #Metodo para obtener el combustible
        return self.combustible
    
    def usar_combustible(self, cantidad):             #Metodo para usar el combustible, que resta el valor que tenga cantidad al combustible
        self.combustible -= cantidad


class Auto():
    def __init__(self, tanque):                       #Tanque es un objeto de TanqueDeCombustible
        self.posicion = 0                             #Atributo estatico
        self.tanque = tanque                          #Atributo de estancia
        
    def mover(self, distancia):                                    #Aqui creamos un metodo para mover el auto, le damos un valor en distancia
        if self.tanque.obtener_combustible() >= distancia / 2:     #Si el combustible que hay en ese momento es mayor o igual a la distancia entre dos (ejemplo: si la distancia es 100, saca 50)
            self.posicion += distancia                             #Primero se mueve el carro a la ubicacion acordada
            self.tanque.usar_combustible(distancia / 2)            #Se usa la funcion de usar el combustible y le decimos que se va a consumir la distancia entre 2 (ejemplo: si la distancia es 100, saca 50)
            print("El auto se movio exitosamente!")
        else:
            print("No hay suficiente combustible")
            
    def obtener_posicion(self):                                    #Fucion para saber la posicion del auto
        return self.posicion
    

        
tanque = TanqueDeCombustible()               #Creamos un tanque
auto = Auto(tanque)                          #Creamos un auto y le pasamos el tanque         

print(auto.obtener_posicion())
print(auto.mover(10))
print(auto.obtener_posicion())
print(auto.mover(30))
print(auto.obtener_posicion())
print(auto.mover(50))
print(auto.obtener_posicion())
print(auto.mover(40))
print(auto.obtener_posicion())
print(auto.mover(80))
print(auto.obtener_posicion())