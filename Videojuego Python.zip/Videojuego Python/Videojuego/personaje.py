import pygame

class Cubo:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.ancho = 70
        self.alto = 70
        self.velocidad = 10
        self.color = "red"
        self.rect = pygame.Rect(self.x, self.y, self.ancho,self.alto)              #"slef.rect" es la forma que tiene pygame de crear objetos y definir su ancho, largo, coordenadas, dimensiones, etc...
        self.imagen = pygame.image.load("Videojuego/space-ship-1.webp")
        self.imagen = pygame.transform.scale(self.imagen, (self.ancho, self.alto))
        
       #self.imagen = pygame.transform.rotate(self.imagen, 90)                     #Por si queremos rotar nuestra imagen
        
    def dibujar(self, ventana):
        self.rect = pygame.Rect(self.x, self.y, self.ancho,self.alto)              #cada vez que llamemos a la funcion "dibujar", tambien tenemos que ponerle este atributo del constructor(self.rect)
        #pygame.draw.rect(ventana, self.color, self.rect)                          #ya que es una manera de actualizar sus cordenadas
        ventana.blit(self.imagen, (self.x, self.y))                                #Para imprimir mi imagen del personaje, le decimos que en la ventana queremos que introduscas algo en la pnatalla (blit())d