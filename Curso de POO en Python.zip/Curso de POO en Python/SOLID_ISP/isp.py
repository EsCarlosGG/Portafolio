from abc import ABC, abstractmethod

class Trabajador(ABC):
    @abstractmethod
    def trabajar(self):
        pass

class Comedor(ABC):
    @abstractmethod
    def comer(self):
        pass
    
class Durmiente(ABC):
    @abstractmethod
    def dormir(self):
        pass
    
    

class Humano(Trabajador, Comedor, Durmiente):
    
    def comer(self):
        print("El humano esta comiendo...")
    
    def trabajar(self):
        print("El humano esta trabajando...")
    
    def dormir(self):
        print("El humano esta durmiendo...")
        
        
        
class Maquina(Trabajador):
    def trabajar(self):
        print("La maquina esta trabajando...")

maquina = Maquina()
humano = Humano()

humano.comer()
humano.dormir()
humano.trabajar()

maquina.trabajar()