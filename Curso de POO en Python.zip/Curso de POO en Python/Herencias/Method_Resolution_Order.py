class A:
    def hablar(self):
        print("Hola desde A")

class K(A):
    def hablar(self):
        print("Hola desde K")
        
class O(A):
    def hablar(self):
        print("Hola desde O")
        
class B(O):
    def hablar(self):
        print("Hola desde B")
        
class C(K):
    def hablar(self):
        print("Hola desde C")
        
class D(B,C):
    def hablar(self):
        print("Hola desde D")


d = D()



                 #Estoy llamando a la clase          #Estoy llamando al objeto de esa clase     #Estoy pasando un objeto para llamarlo como self
O.hablar(d)         #===== O ======                          #====== .hablar ========                   #======== (d) ===========

#Aqui ejecutamos el metodo de un orden superior con la clase que ereda todas las anteriores





#print(D.mro())         #se usa para saber la jerarquia de clases para llamara a algo, el orden de ejecucion por jerarquia