from calculadora import calculadora_analogica
from contador_de_calorias import Contador_calorias
from factorial import num_factorial
from tablas_multiplicar import tablas_multi

    
while True:
    print("\n1. Calculadora")
    print("2. Contador de calorias")
    print("3. Numero factorial")
    print("4. Tablas de multiplicar")
    print("5. Agregar, Editar y Leer texto.txt")
    opcion = input("Eliga una opcion: ")
    
    value1 = opcion.lower()
    opcion = value1.capitalize()
    
    if opcion == "1":
        print(" === Calculadora === ")
        print("--> Suma")
        print("--> Resta")
        print("--> Multiplicacion")
        print("--> Division")
        valor1 = input("""
                       Eliga una opcion: """)
        valor2 = valor1.lower()
        opcion = valor2.capitalize()
        iniciar_calculadora = calculadora_analogica(opcion)
        print(iniciar_calculadora)
        
    elif opcion == "2":
        genero = int(input("ingrese su genero:   1. Hombre  2. Mujer  :"))
        peso = int(input("ingrese su peso en kg: "))
        altura = int(input("ingrese su estaura en cm: "))
        edad = int(input("ingrese su edad: "))
        actividad = int(input('''Estilo de vida:
                              1. Sedentario
                              2. Ligeramente activo
                              3. Activo o Moderadamente Activo
                              4. Atleta de alto rendimiento
                              : '''))
        iniciar_contador_calorias = Contador_calorias(genero, peso, altura, edad, actividad)
        print(iniciar_contador_calorias)
        
    elif opcion == "3":
        n = int(input("Ingrese un numero para factorial: "))
        iniciar_factorial = num_factorial(n)
        print(iniciar_factorial)
        
    elif opcion == "4":
        num = int(input("Ingrese el numero de tablas que quiere: "))
        iniciar_tablas = tablas_multi(num)
        print(iniciar_tablas)
        
    elif opcion == "5":
        print("\n1.- Agregar")
        print("2.- Leer\n")
        
        opcion_txt = input("Eliga una opcion: ")
        
        if opcion_txt == "1":
            with open("ejercicios_modulos\\texto_de_carlos_2.txt","a") as archivo:
                lineas = int(input("\nCuantas lineas quieres agregar?: "))
                for i in range(lineas):
                    contenido = input(f"Que quieres poner en la linea {i+1}?: ")
                    archivo.write(f"\nLinea {i+1}: {contenido}\n")
                    print("Se agrego correctamente!")
        elif opcion_txt == "2":
            with open("ejercicios_modulos\\texto_de_carlos_2.txt") as archivo:
                leer = archivo.read()
                print(leer)
        else:
            print("""
                  /// Opcion no valida ///
                  
                  --- Eliga nuevamente ---
                  """)
            
    else:
        print("""
              /// Opcion no valida ///
              
              --- Eliga nuevamente ---
              """)