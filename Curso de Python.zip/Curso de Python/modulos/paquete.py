import paquete.saludar_raro

print(paquete.saludar_raro.saludar_raro("Carlos"))