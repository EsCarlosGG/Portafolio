
with open("archivos\\texto_de_carlos.txt","w") as archivo:
    #sobreescribiendo el archivo
    #archivo.write("ja ja ja ja men te cambie todo el quilombo")
    
    #agregando 2 lineas con writelines
    archivo.writelines([" - Hola capo, como andas\n"," - por esparta\n"])
    
    #agregando otras 2 lineas
    archivo.writelines([" - Ni me gusta esa peli\n"," - a bueno\n"])