#///////Tipo real////////
x = 10
print(type(x))  # <class 'int'>

x = "Hola"
print(type(x))  # <class 'str'>

x = 3.14
print(type(x))  # <class 'float'>


#POO
class Animal:
    def hablar(self) -> str:
        return "El animal hace un sonido"

def hacer_hablar(animal: Animal) -> None:
    print(animal.hablar())

mi_animal: Animal = Animal()
hacer_hablar(mi_animal)



#/////// Tipo declarado ///////

class Perro:
    def hablar(self):
        return "El perro ladra"

class Gato:
    def hablar(self):
        return "El gato maúlla"

def hacer_hablar(animal):
    print(animal.hablar())

mi_perro = Perro()
mi_gato = Gato()

print(type(mi_perro))  # <class '__main__.Perro'>
print(type(mi_gato))   # <class '__main__.Gato'>

hacer_hablar(mi_perro)  # El perro ladra
hacer_hablar(mi_gato)   # El gato maúlla
