
#Definiendo una variable
nombre = "Carlos"

#concatenar con +
bienvenida = "Hola" + "Como estas?"

#concatenar o encadenar con f-string
bienvenida = f"Hola {nombre} Como estas"


#operadores de pretenencia (in / not in)

print("Carlos" in bienvenida)  # True

print("Carlos" not in bienvenida)  #False





#Definiendo una variable con camelCase
nombreCompletoDeTuMaster = "Carlos"

#Definiendo una variable con snake_case
nombre_completo_de_tu_master = "Carlos"


