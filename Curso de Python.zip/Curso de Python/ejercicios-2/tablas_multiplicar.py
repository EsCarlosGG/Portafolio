

for i in range(1,11):
    print("tabla del", i)
    for j in range(1,11):
        print(f" {i} x {j} = {i*j}")
