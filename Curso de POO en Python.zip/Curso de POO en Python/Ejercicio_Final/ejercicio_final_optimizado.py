import openai

openai.api_key = "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"

system_rol = '''Haz de cuenta que eres un analizador de sentimeintos.
                 Yo te paso sentimientos y tu analizas el sentimiento de los mensajes
                 y me das una respuesta con al menos 1 caracter y como maximo 4 caracteres
                 SOLO RESPUESTAS NUMERICAS. Donde -1 es negatividad maxima, 0 es neutral y 1 es positividad maxima.
                 Puedes ir entre esos rangos, 0.3, -0.5 etc tambien son validos.
                 (Puedes responder solo con ints o floats)'''
                                                                                                                         
mensajes = [{"role": "system", "content": system_rol}]

class Sentiemiento:                                                           #Sentimiento ahora tiene la responsabilida unica que representa un sentimiento y su color
    def __init__(self, nombre, color):
        self.nombre = nombre
        self.color = color
        
    def __str__(self):
        return "\x1b[1;{}m{}\x1b[0;37m".format(self.color, self.nombre)       #".format()" le da formato, en el primer "{}" le da color y el segundo le da el nombre (el sentimiento), remplaza las {}
                                                                          
class AnalizadorDeSentimientos:                                               #AnalizadorDeSentimientos tiene la responsabilidad de definirnos cual va a ser el sentimiento
    def __init__(self, rangos):                                               #Cumple el Open/Close principle
        self.rangos = rangos
        
    def analizar_sentimiento(self, polaridad):
        for rango, sentiemiento in self.rangos:                               #desempaqutamos con rango y sentimiento, entonces self.rangos sera una tupla con dos tuplas adentro (rangos y sentimientos)
            if rango[0] < polaridad <= rango[1]:                              #Si la polaridad se encuentra en este rango nos devuelve sentimiento que tenia asociado
                return sentiemiento
        return Sentiemiento("Muy negativo", "31")
        
rangos = [
    ((-0.8,-0.3), Sentiemiento("Negativo","31")),
    ((-0.3,-0.1), Sentiemiento("Algo negativo","31")),
    ((-0.1,0.1), Sentiemiento("Neutral","33")),
    ((0.1,0.4), Sentiemiento("Algo Positivo","32")),
    ((0.4,0.9), Sentiemiento("Positivo","32")),
    ((0.9,1), Sentiemiento("Muy Positivo","32"))
]
        
analizador = AnalizadorDeSentimientos(rangos)

while True:
    user_prompt = input("\x1b[1;33m" + "\nDime Algo: "  + "\x1b[0;37m")
    mensajes.append({"role": "user", "content": user_prompt})
    
    completion = openai.ChatCompletion.create(
        model = "gpt-3.5-turbo",
        messages = mensajes,
        max_tokens = 8
    )
    
    respuesta = completion.choices[0].message["content"]
    mensajes.append({"role": "assistant", "content": respuesta})
    
    sentimiento = analizador.analizar_sentimiento(float(respuesta))
    print(sentimiento)