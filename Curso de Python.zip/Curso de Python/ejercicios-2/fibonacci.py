#Pidiendole al usuario el numero
num = int(input("Ingrese el numero para el Fibonacci: "))

f0,f1 = 0,1
fibonacci_lista = [0]
for i in range(num):
    if f1 > num:
        fibonacci_lista
    else:
        fibonacci_lista.append(f1)
        f0,f1 = f1,f0+f1
    fibonacci_lista

print(fibonacci_lista)