#2 listas, una con nombres otra con apellidos
nombres = ["Carlos","Francisco","Tadeo","Steve","Roberto"]
apellidos = ["Garnica","Contreras","Fernandez","Craft","Garcia"]

#Registrar esta informacion en un TXT de forma optima

with open("archivo_problemas_resueltos\\nombres_y_apellidos.txt","w") as arch:
    arch.writelines("Los datos son:\n\n")
    [arch.writelines(f"Nombre: {n} \nApellidos: {a}\n-----------\n") for n,a in zip(nombres,apellidos)]