import re

text = "remplazando todas las vocales por el asteriscos"

new_text = re.sub("[aeiou]", "*", text)                       #Con: [], le decimos que nos busque cada letra por separado

print(new_text)