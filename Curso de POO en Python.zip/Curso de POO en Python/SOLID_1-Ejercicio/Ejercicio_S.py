import math

class Circulo:
    def __init__(self, radio):
        self.radio = radio
        
    def area(self):
        return 3.1416 *  (self.radio ** 2)
    
class Rectangulo:
    def __init__(self, lado_1, lado_2):
        self.lado_1 = lado_1
        self.lado_2 = lado_2
        
    def area(self):
        return self.lado_1 * self.lado_2

class TrianguloEquilatero:
    def __init__(self, base, altura):
        self.base = base
        self.altura = altura
        
    def area(self):
        return (self.base * self.altura) / 2

class CalcularArea:
    def __init__(self, figuras):
        self.figuras = figuras
        
    def area_total(self):
        total = 0
        for figura in self.figuras:
            total += figura.area()
        return total

circulo = Circulo(3)
figura = CalcularArea()

print(circulo.area())
