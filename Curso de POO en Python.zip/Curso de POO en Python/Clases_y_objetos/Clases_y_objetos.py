
#Aqui definimos la clase
class Celular:
    def __init__(self, marca, modelo, camara):
        self.marca = marca
        self.modelo = modelo
        self.camara = camara
    
    def llamar(self):
        print(f"Estas haciendo una llamada desde un: {self.marca}")
    
    def cortar(self):
        print(f"Cortaste la llamada desde el: {self.marca}")



celular1 = Celular("Apple","17pro+/","48MP")
celular2 = Celular("Samsung","S23","48MP")

celular2.llamar()
