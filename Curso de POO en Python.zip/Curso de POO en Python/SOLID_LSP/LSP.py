# class Ave:
#     def volar(self):
#         return "Estoy volando"
    
# class Pinguino(Ave):
#     def volar(self):
#         return "No puedo volar"
    
# def hacer_volar(ave = Ave):
#     return ave.volar()

# print(hacer_volar(Pinguino()))

class Ave:
    pass                            #Aqui podemos definir todo lo que todas las aves pueden hacer, sin esepciones

class AveVoladora(Ave):
    def volar(self):                #En las demas clases ya podemos especificar sus atributos y cosas que si pueden hacer
        return "Estoy Volando"
    
class AveNoVoladora(Ave):
    def volar(self):
        return "No puedo Volar"
    
def imprimir_informacion(ave):
    print(ave.volar())


pichon = AveVoladora()
pinguino = AveNoVoladora()

imprimir_informacion(pichon)
imprimir_informacion(pinguino)