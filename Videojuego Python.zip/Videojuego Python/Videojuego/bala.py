import pygame
import time
import random

class Bala:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.ancho = 10
        self.alto = 10
        self.velocidad = 10
        self.color = "red"
        self.rect = pygame.Rect(self.x, self.y, self.ancho,self.alto)              #"slef.rect" es la forma que tiene pygame de crear objetos y definir su ancho, largo, coordenadas, dimensiones, etc...
        self.last_move_time = pygame.time.get_ticks()                              #Guarda el tiempo del utlimo movimiento
        
    def dibujar(self, ventana):
        self.rect = pygame.Rect(self.x, self.y, self.ancho,self.alto)              #cada vez que llamemos a la funcion "dibujar", tambien tenemos que ponerle este atributo del constructor(self.rect)
        pygame.draw.rect(ventana, self.color, self.rect)                           #ya que es una manera de actualizar sus cordenadas
        
    def movimiento(self):
        self.y -= self.velocidad                                                   #Aqui le damos movimiento, usamos el eje y, va en subida
    
    def fuera_pantalla(self, alto_ventana):
        return self.y > alto_ventana