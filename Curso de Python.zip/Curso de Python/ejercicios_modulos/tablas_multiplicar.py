def tablas_multi(num):
    for i in range(1,num+1):
        print("Tabla del", i)
        for j in range(1,11):
            print(f"""|| {i} x {j} = {i*j} ||""")