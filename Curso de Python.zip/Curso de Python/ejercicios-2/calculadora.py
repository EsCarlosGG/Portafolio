
def suma():
    suma1 = int(input("Ingrese el primer numero a sumar: "))
    suma2 = int(input("Ingrese el segundo numero a sumar: "))
    resultado_suma = suma1 + suma2
    print(f"{suma1} + {suma2} = {resultado_suma}")\

def resta():
    resta1 = int(input("Ingrese el primer numero a restar: "))
    resta2 = int(input("Ingrese el segundo numero a restar: "))
    resultado_resta = resta1 - resta2
    print(f"{resta1} - {resta2} = {resultado_resta}")
    
def multiplicacion():
    multi1 = int(input("Ingrese el primer numero a multiplicar: "))
    multi2 = int(input("Ingrese el segundo numero a multiplicar: "))
    resultado_multi = multi1 * multi2
    print(f"{multi1} * {multi2} = {resultado_multi}")
    
def division():
    divi1 = int(input("Ingrese el primer numero a dividir: "))
    divi2 = int(input("Ingrese el segundo numero a dividir: "))
    resultado_divi = divi1 / divi2
    print(f"{divi1} / {divi2} = {resultado_divi}")

while True:
    print(" === Calculadora === ")
    print("--> Suma")
    print("--> Resta")
    print("--> Multiplicacion")
    print("--> Division")
    
    valor1 = input("""
                   Eliga una opcion: """)
    valor2 = valor1.lower()
    opcion = valor2.capitalize()
    
    if opcion == 'Suma':
        suma()
    elif opcion == 'Resta':
        resta()
    elif opcion == 'Multiplicacion':
        multiplicacion()
    elif opcion == 'Division':
        division()
    else:
        print("""
              Opcion no valida.
              
              Eliga nuevamente: """)