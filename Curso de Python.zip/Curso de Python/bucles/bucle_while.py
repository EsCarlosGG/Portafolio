#creando un contador que va a ir sumandose
contador = 0

#mientras que la condicion se cumpla, el bucle se va a seguir ejecutando
# (vuelta, tras vuelta se verifica la condicion)
while contador < 10:
    contador += 1
    print(contador)

    
print("el while llego a su fin")