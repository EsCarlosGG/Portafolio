#creando los datos
datos_en_tupla = ("Carlos","Garnica",18)
datos_en_lista = ["Carlos","Garnica",18]

#desempaquetado
nombre,apellido,edad = datos_en_tupla

#mostrando resultados
print(apellido)