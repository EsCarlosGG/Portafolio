class Persona:
    def __init__(self,nombre,edad,nacionalidad):
        self.nombre = nombre
        self.edad = edad
        self.nacionalidad = nacionalidad
    
    def hablar(self):
        print(f"Hola, soy {self.nombre} y estoy hablando")

class Empleado(Persona):
    def __init__(self,nombre,edad,nacionalidad,trabajo,salario):
        super().__init__(nombre,edad,nacionalidad)               #Utilizamos la funcion super() para hacer la erencia de la clase 'padre' a la clase 'hija'
        self.trabajo = trabajo
        self.salario = salario
        
class Estudiante(Persona):
    def __init__(self,nombre,edad,nacionalidad,notas,grado):
        super().__init__(nombre,edad,nacionalidad)
        self.notas = notas
        self.grado = grado
        
humano = Empleado("Maximiliano",28,"Andorrano","Programador",100000)

print(humano.trabajo)
humano.hablar()