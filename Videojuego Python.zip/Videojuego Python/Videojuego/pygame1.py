import pygame
from personaje import Cubo                               #Importamos nuestro personaje, desde su clase
from enemigo import Enemigo
import random
from bala import Bala
from items import Item

pygame.init()                                            #Algunas fuentes necesitan esto

pygame.mixer.init()

#Definimos los margenes de nuestra ventana
ANCHO = 1000                                                    #Las ponemos en Mayusculas ya que son constantes
ALTO = 800
VENTANA = pygame.display.set_mode([ANCHO,ALTO])                 #Aqui usamos la libreria pygame, el ".display" tiene que ver todo lo que sea de la pantalla
FPS = 60
FUENTE = pygame.font.SysFont("Comic Sans", 40)                  #Usamos una fuente donde pondremos texto, definimos su fuente y su tamaño
SONIDO_SHOOT = pygame.mixer.Sound('Videojuego/SHOOT.mp3')
SONIDO_EXPLOSION = pygame.mixer.Sound('Videojuego/EXPLOSION.mp3')
SONIDO_JUEGO = pygame.mixer.Sound('Videojuego/Aliens-Sound2.mp3')
SONIDO_ALIENS = pygame.mixer.Sound('Videojuego/Arrival-Sound.mp3')

#Para que no se cierre nuestro programa usaremos un bucle
jugando = True

reloj = pygame.time.Clock()                                     #Usamos "time" para todo lo que tenga que ver con el tiempo

vida = 5                                                        #sistema de vidas
puntos = 0                                                      #sistema de puntos
vida_extra = 1000
puntos_vida_extra = 0


tiempo_pasado = 0
tiempo_entre_enemigos = 500                                     #Esta es la cantidad en milisegundos que tiene que pasar para que vayan apareciendo enemigos
tiempo_entre_enemigos_base = 1000

tiempo_entre_items = 6000

cubo = Cubo(ANCHO/2.2,ALTO-75)                                  #Definimos las coordenadas(ubicacion) de nuestro personaje, en este caso: x = seria a la maitad, y = parte de abajo

enemigos = []                                                   #Definiremos una lista de todos los "enemigos" que van a haber

items = []
ultimo_item = 0

balas = []                                                      #Creamos una lista de balas

ultima_bala = 0
intervalo_entre_balas = 150
tiempo_entre_bala = 300
proxima_bala = "derecha"

enemigos.append(Enemigo(ANCHO/2,100))

items.append(Item(ANCHO/2,100))

def crear_bala():                                               #Definimos una funcion para crear una bala
    global ultima_bala, proxima_bala                                          #Con el "global" podemos llegar a modificar el valor de una variable dentro de una funcion
    
    if proxima_bala == "derecha" and pygame.time.get_ticks() - ultima_bala > tiempo_entre_bala:    #Si el tiempo de que inicio el juego menos el tiempo en que se lanzo la ultima bala es mayor a tiempo entre balas se dibuja una bala
        balas.append(Bala(cubo.rect.right-17, cubo.rect.centery-25))
        ultima_bala = pygame.time.get_ticks()                         #Receteamos
        SONIDO_SHOOT.play()
        proxima_bala = "izquierda"
        
    elif proxima_bala == "izquierda" and pygame.time.get_ticks() - ultima_bala > intervalo_entre_balas:
        balas.append(Bala(cubo.rect.left+5, cubo.rect.centery-25))
        ultima_bala = pygame.time.get_ticks()                         #Receteamos
        SONIDO_SHOOT.play()
        proxima_bala = "derecha"

def crear_item():
    global ultimo_item
    
    if pygame.time.get_ticks() - ultimo_item > tiempo_entre_items:
        ultimo_item = pygame.time.get_ticks()
        items.append(Item(random.randint(100, ANCHO-100),-100))

def gestionar_teclas(teclas):
    # if teclas[pygame.K_w]:                                           #Cuando ponemos "K" en pygame, nos referimos a las teclas, en este caso usaremos la w
    #     cubo.y -= cubo.velocidad
    # if teclas[pygame.K_s]:
        # cubo.y += cubo.velocidad
    if teclas[pygame.K_a]:
        if cubo.x >= 0:
            cubo.x -= cubo.velocidad
    if teclas[pygame.K_d]:
        if cubo.x + cubo.ancho <= ANCHO:
            cubo.x += cubo.velocidad
    if teclas[pygame.K_SPACE]:
        crear_bala()

while jugando and vida > 0:                                           #"and vida > 0" es para que si tenemos mas de 0 vidas, el juego seguira, si no, el juego termina
    
    tiempo_pasado += reloj.tick(FPS)                                  #Esto hara que todo se mueva mas lento, y sera parejo para cualquier pc(con cualquier especificacion)
                                                                      #tambien lo que hace es que se van añadiendo todos los milisegundos que pasan
    
    if tiempo_pasado > tiempo_entre_enemigos:                         #Cuando "tiempo_pasado" sea mayor a 500 milisegundos (tiempo_entre_enemigos)
        enemigos.append(Enemigo(random.randint(0,ANCHO),-100))                                               #a nuestra lista de enemigos se creara un nuevo enemigo, y utilizamos "random" para que aparezcan aleatoriamente, entre el 0 y el ancho total de mi pantalla (en el eje X), en el eje Y es en -100 (mas arriba de la pantalla)
        tiempo_pasado = 0                                             #Ademas "tiempo_pasado" se recetea a 0, esto para que sean enemigos diferentes            
        tiempo_entre_enemigos = random.randint(50, tiempo_entre_enemigos_base)
        if tiempo_entre_enemigos_base > 80:
            tiempo_entre_enemigos_base -= 10
    
    eventos = pygame.event.get()                                      #Esto nos va a devolver una lista con to6ddos los eventos que hay
    teclas = pygame.key.get_pressed()                                 #".key" para todo lo que sea del teclado
    
    texto_vida = FUENTE.render(f"Vida: {vida}", True, "red")          #le damos forma al texto de la vida
    texto_puntos = FUENTE.render(f"Puntos: {puntos}", True, "blue")   #le damos forma al texto de los puntos
    
    gestionar_teclas(teclas)
    
    for evento in eventos:
        if evento.type == pygame.QUIT:                          #Si el evento es quitar la pantalla (eliminar la pestaña), etc... la ventana cerrara
            jugando = False
    
    
    VENTANA.fill("black")                                       #En cada vuelta, del bucle principal, la pantalla se llenara de negro         
    cubo.dibujar(VENTANA)                                       #<--Cada vez que nuestro bucle de una vuelta...
    
    enemigos_a_eliminar = []                                    #Creamos una lista para enemigos eliminados
    colision_detectada = False
    
    for enemigo in enemigos:
        enemigo.dibujar(VENTANA)                                #Con esto dibujamos al enemigo
        enemigo.movimiento()                                    #y le damos movimiento, en este caso cae

        if pygame.Rect.colliderect(cubo.rect, enemigo.rect):    #por cada vez que el personaje toque un enemigo,
            vida -= 1                                           #se le resta 1 vida
            print(f"Te quedan: {vida} vidas!")                  #aparece un aviso
            enemigos_a_eliminar.append(enemigo)
            colision_detectada = True
                   
        if enemigo.y > ALTO:                     #Si la suma del recorrido del enemigo en el eje "y", y la cantidad del alto del enemigo es mayor al alto de la pantalla
            enemigos.remove(enemigo)
        
        if puntos >= 0:                                                         #Si los puntos son menos o iguales a 0, aparecera que estas perdiendo
            texto_puntos
        else:
            texto_puntos = FUENTE.render("Estas perdiendo", True, "red")
        
        for bala in balas:
            if pygame.Rect.colliderect(bala.rect, enemigo.rect):                 #Aqui lo que hacemos es que cuando una bala toque algun enemigo, el enemigo desaparecera y la bala tambien, y nos umara 10 puntos
                enemigo.vida -= 1
                balas.remove(bala)
        
        if enemigo.vida <= 0:
            enemigos.remove(enemigo)
            puntos += 10
            SONIDO_EXPLOSION.play()
            
    for bala in balas:                                           #Aqui la bala se ira creando con forma va pasando el tiempo de juego y presionamos la tecla Espacio
        bala.dibujar(VENTANA)
        bala.movimiento()
        
        if bala.fuera_pantalla(ALTO):         #para eliminar las balas que sobre pasen la pantalla
            balas.remove(bala)
    
    for item in items:
        item.dibujar(VENTANA)
        item.movimiento()
    
        if pygame.Rect.colliderect(item.rect, cubo.rect):
            items.remove(item)
            puntos_vida_extra += 100
            
            if item.tipo == 1:
                if tiempo_entre_bala > 200:
                    tiempo_entre_bala /= 2
            elif item.tipo == 2:
                if puntos_vida_extra == vida_extra:
                    vida += 1
                    puntos_vida_extra = 0
                
        if item.y > ALTO:
            items.remove(item)
    
    crear_item()
    
    if puntos > 100:                                              #Es algun tipo de nivel 2
        cubo.velocidad = 15
        intervalo_entre_balas = 10
        enemigo.velocidad = 10
        item.velocidad = 10
            
    for enemigo in enemigos_a_eliminar:                         #Se itera cada enemigo en la lista de eliminados, y se elimina de la lista original de Enemigos
        enemigos.remove(enemigo) 
    
    VENTANA.blit(texto_vida, (20,20))                           #Lo ponemos hasta abajo para que se superponga usando "blit()", blit agarra un objeto y lo pega en la pantalla
    VENTANA.blit(texto_puntos, (ANCHO/2*1.4,20))
    
    pygame.display.update()                                     #Esto hace que nuestra pantalla se mantenga actualizandose

pygame.quit()

nombre = input("Introduce tu Nombre: ")

with open('Videojuego\\puntuaciones.txt','a') as archivo:
    archivo.write(f"{nombre} - {puntos}\n")

quit()