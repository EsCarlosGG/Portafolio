import pandas as pd

#usando la funcion read_csv para leer el archivo CSV
df = pd.read_csv("archivos\\datos.csv")
df2 = pd.read_csv("archivos\\datos.csv")

#obteniendo los datos de la columna nombre
nombres = df["nombre"]

#usamos [:] para especificar en donde empieza y termina el compilado de una cadena en este caso.
#cadena = "0123456789"
#print(cadena[:])




#ordenando el dataframe por la edad
df_orden_ascendente = df.sort_values("edad")

#ordenando el dataframe por la edad
df_orden_descendente = df.sort_values("edad",ascending=False)



#concatenando los 2 dataframes
df_concatenado = pd.concat([df,df2])



#accediendo a las primeras 3 fila con head()
primeras_filas = df.head(3)

#accediendo a las ultimas 2 fila con head()
uiltimas_filas = df.tail(2)

#accediendo a la cantidad de filas y columnas con shape
filas_totales,columnas_totales = df.shape



#obteniendo data estadistica del dataframe:
df_info = df.describe()



#accediendo a la edad de la fila 2 con loc
elemento_especifico_loc = df.loc[4,"edad"]

#accediendo a la edad de la fila 2 con iloc
elemento_especifico_loc = df.iloc[4,2]



#accediendo a todos los apellidos con loc
apellidos = df.loc[:,"apellido"]

#accediendo a todos los apellidos con iloc
apellidos = df.iloc[:,1]



#accediendo a la fila 3 con loc
fila_3 = df.loc[2,:]

#accediendo a la fila 3 con iloc
fila_3 = df.iloc[2,:]



#accediendo a filas con edad mayor que 30
mayor_que_30 = df.loc[df["edad"]<30,:]



print(mayor_que_30)