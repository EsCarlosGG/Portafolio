from abc import ABC, abstractmethod

#Clase del area
class Area(ABC):
    @abstractmethod
    def area(self):
        pass
    
#Clase de Figuras 3D
class Volumen(ABC):
    @abstractmethod
    def volumen(self):
        pass


#Definimos clases de figuras que son 2D
class Cuadrado(Area):
    def __init__(self, lado):
        self.lado = lado
        
    def area(self):
        return self.lado * self.lado
    
class Circulo(Area):
    def __init__(self, radio):
        self.radio = radio
        
    def area(self):
        return 3.1416 * (self.radio ** 2)
    
class TrianguloEquilatero(Area):
    def __init__(self, base, altura):
        self.base = base
        self.altura = altura
        
    def area(self):
        return (self.base * self.altura) / 2
    
class Rectangulo(Area):
    def __init__(self, lado_1, lado_2):
        self.lado_1 = lado_1
        self.lado_2 = lado_2
        
    def area(self):
        return self.lado_1 * self.lado_2
    

#Ahora definimos figuras 3D
class Cubo(Area, Volumen):
    def __init__(self, lado):
        self.lado = lado
        
    def area(self):
        return 6 * (self.lado ** 2)
    
    def volumen(self):
        return pow(self.lado, 3)
    
class PrismaRectangular(Area, Volumen):
    def __init__(self, long_ancho, long_base, long_altura):
        self.long_ancho = long_ancho
        self.long_base = long_base
        self.long_altura = long_altura
        
    def area(self):
        return 2 * (self.long_ancho + self.long_base + self.long_altura)
    
    def volumen(self):
        return (self.long_ancho * self.long_base * self.long_altura)
    
class Cilindro(Area, Volumen):
    def __init__(self, radio, altura):
        self.radio = radio
        self.altura = altura
        
    def area(self):
        return 2 * (3.1416 * self.radio) * (self.radio + self.altura)
    
    def volumen(self):
        return (3.1416 * (self.radio ** 2) * self.altura)
    
class Esfera(Area, Volumen):
    def __init__(self, radio):
        self.radio = radio
        
    def area(self):
        return 4 * (3.1416 * (self.radio ** 2))
    
    def volumen(self):
        return (4 * (3.1416 * (pow(self.radio, 3)))) / 3


class Calculadora:
    def __init__(self, area_figura: Area, volumen_figura: Volumen = None):
        self.area_figura = area_figura
        self.volumen_figura = volumen_figura
        
    def calcular_area(self):
        return self.area_figura.area()
    
    def calcular_volumen(self):
        if self.volumen_figura:
            return self.volumen_figura.volumen()
        else:
            return "Esta figura no tiene volumen"
        

cuadrado = Cuadrado(4)
esfera = Esfera(3)

cubo = Cubo(4)

calculadora_area_volumen_cubo = Calculadora(cubo, cubo)


calculadora_area_cuadrado = Calculadora(cuadrado)
calculadora_area_volumen_esfera = Calculadora(esfera, esfera)

print(calculadora_area_cuadrado.calcular_area())  # Salida: 16
print(calculadora_area_volumen_esfera.calcular_area())  # Salida: 113.0976
print(calculadora_area_volumen_esfera.calcular_volumen())  # Salida: 113.0976

print(calculadora_area_volumen_cubo.calcular_volumen())
print(calculadora_area_volumen_cubo.calcular_area())