class Pato:
    def graznar(self):
        return "¡Cuac cuac!"

class Persona:
    def graznar(self):
        return "Estoy graznando como un pato"

def hacer_graznar(ave):
    print(ave.graznar())

pato = Pato()
persona = Persona()


print(pato.graznar())
print(persona.graznar())
hacer_graznar(pato)     # ¡Cuac cuac!
hacer_graznar(persona)  # Estoy graznando como un pato