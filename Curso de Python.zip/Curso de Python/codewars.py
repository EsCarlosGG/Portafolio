lista_nombres = ["Peter","Parker"]

if len(lista_nombres) == 0:
    print("no one likes this.")
else:
    for nombre in range(len(lista_nombres)):
        if nombre == 0:
            print(f"{lista_nombres[nombre]} like this.")
        if nombre == 1:
            print(f"{lista_nombres[nombre]} and {lista_nombres[nombre]} like this")
            

