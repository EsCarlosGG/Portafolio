#Creando una lista con list()
lista = list([44, 55, 556, False, True])

#devuelve la canitdad de elementos de la lista
cantidad_elementos = len(lista)

#agregando un elemento a la ista
lista.append(2134)

#agregando un elemento a la lista en un indice especifico
lista.insert(2, "Helouda we")

#agregando vartios elementos a la lista
lista.extend([False, 2025])

#eliminando un elemento de la lista (por su indice)
lista.pop()    #-1 para eliminar el ultimo, -2 para eliminar el antepenultimo, y a si sucesivamente

#removiendo un elemento de la lista por su valor
lista.remove("Helouda we")

#eliminando todos los elementos de la lista
#lista. clear()

#ordenando la lista de forma acendente (si usamos el parametro reverse=True lo ordena en reversa)
lista.sort()

#inviertiendo los elementos de una lista
lista.reverse()


#verificando si un elemento se enceuntra en la lista
elemento_encontrado = lista.index(55)


print(elemento_encontrado)