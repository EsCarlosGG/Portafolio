#pedirle un numero al usuario
numero = input("dame un numero: ")

#convierto el numero (que es string) a entero (int) y lo multiplico por 2
resultado_entero = int(numero) * 2

#convierto el flotante (que es float) a entero (int) y lo multiplico por 2
resultado_flotante = float(numero) * 2

#mostrando el resultado
print(resultado_flotante)