
igual_que = 5 == 6

distinto_de = 5!= 6

mayor_que = 5 > 6

menor_que = 5 < 6

mayor_o_igual = 5 >= 6

menor_o_igual = 5 <= 6


#calulos combinados

a = 5
b = 10
c = 20
comparacion = a + b < c

#comparar usuario
contraseña_almacenada = "EsCarlosGG"

contraseña_escrita = "Carlos"



print(contraseña_almacenada == contraseña_escrita)