

class Celular:
    def __init__(self, marca, modelo, camara):
        self.marca = marca
        self.modelo = modelo
        self.camara = camara
    
    #utilizamos metodos para realizar acciones en una clase
    #Siempre se pone el "self" como parametro principal del metodo
    def llamar(self):
        print(f"Estas haciendo una llamada desde un: {self.marca}")    #Si queremos hacer mencion de un atributo se pone self como en el constructor
    
    def cortar(self):
        print(f"Cortaste la llamada desde el: {self.marca}")



celular1 = Celular("Apple","17pro+/","48MP")
celular2 = Celular("Samsung","S23","48MP")

celular2.llamar()