cadena1 = "Hola, Carlos, Como, Estas?"
cadena2 = "Hola perro"


#convierte a mayusculas
mayus = cadena1.upper()

#convierte a minusculas
minus = cadena1.lower()

#convierte primera letra a mayuscula
primer_letra_mayus = cadena1.capitalize()

#buscamos una cadena en otra cadena, si no hay coincidencias devuelve -1
busqueda_find = cadena1.find("C")

#buscamos una cadena en otra cadena, si no hay coincidencias lanza una exception
busqueda_index = cadena1.index("a")

#si es numerico, devolvemos true, si no devolvemos false
es_numerico = cadena1.isnumeric()

#si es alfanumerico devolvemos true, sino devolvemos false
es_alfanumerico = cadena1.isalpha()

#contamos  las coincidencias de una cadena, dentro de otra cadena, devuelve la cantidad de coincidencias
contar_coincidencias = cadena1.count("a")

#contamos cuantos caracteres tiene una cadena
contar_caracteres = len(cadena1)

#verificamos si una cadena empieza con otra cadena dada, si es asi, devuelve True
empieza_con = cadena1.startswith("o")

#verificamos si una cadena termina con otra cadena dada, si es asi, devuelve True
termina_con = cadena1.endswith("s")

#remplaza un pedazo de la cadena dada, por otra dada
cadena_nueva = cadena1.replace("Hola","Que pedo")

#Separar cadenas con la cadena que le pasemos
cadena_separada = cadena1.split(",")                               #lo devuelve en lista

print(cadena_separada)