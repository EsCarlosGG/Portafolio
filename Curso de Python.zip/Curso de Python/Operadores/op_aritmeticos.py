#suma y resta (+ y -)
suma = 12 + 5
resta = 12 - 5


#multi y division ( *  y  / )
multi = 12 * 5
division = 12 / 5  #devuelve un dato float (flotante)


# potenciacion (exponente) (**)
exponente = 12 ** 5

#division baja ( // )
division_baja = 12 // 5  #devuelve entero redondeado hacia abajo

#resto o modulo ( % )
resto = 12 % 5

#type(dato) nos devuelve que tipo de dato es
tipo_de_dato = type(division_baja)



print(tipo_de_dato)

