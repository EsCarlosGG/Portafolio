class Auto():
    def __init__(self):
        self._estado = "apagado"
        
    def encender(self):
        self._estado = "encendido"
        print("El auto esta encendido")
        
    def conducir(self):
        if self._estado == "apagado":
            self.encender()
        print("Conduciendo el auto")

mi_auto = Auto()
mi_auto.conducir()                #Haciendo esto, lo que estamos logrando es que ocultamos toda la logica detras de conducir un auto (en este ejemplo),
                                  #se comprueba si el auto esta encendido, etc...