class Personaje:
    def __init__(self, nombre, fuerza, velocidad):
        self.nombre = nombre
        self.fuerza = fuerza
        self.velocidad = velocidad
        
    def __repr__(self):
        return f'{self.nombre} (fuerza: {self.fuerza}, Velocidad: {self.velocidad})'
    
    def __add__(self,otro_pj):
        nuevo_nombre = self.nombre + "-" + otro_pj.nombre
        nueva_fuerza = round(((self.fuerza + otro_pj.fuerza)/2)**1.5)
        nueva_velocidad = round(((self.velocidad + otro_pj.velocidad)/2)**1.5)
        return Personaje(nuevo_nombre, nueva_fuerza, nueva_velocidad)
    
def agregar_personaje():
    nombre = input("Ingrese el nombre del Personaje: ")
    fuerza = float(input("Ingrese la fuerza del Personaje: "))
    velocidad = float(input("Ingrese la velocidad del Personaje: "))
    return Personaje(nombre, fuerza, velocidad)
    
def mostrar_personaje(personajes):
    if not personajes:
            print("No se encontro ningun personaje...\n")
    else:
        print("\n\n== Personajes disponibles ==\n")
        for i, personaje in enumerate(personajes):
            print(f"{i + 1}.- {personaje}")

personajes = []

while True:
    print("\n == Bienvendio == \n")
    print("1. Agregar personaje")
    print("2. Fusionar personajes")
    print("3. Mostrar personajes")
    print("4. Salir")
    opcion = input("\nSeleccione una opcion: ")
    
    if opcion == "1":
        personaje_nuevo = agregar_personaje()
        personajes.append(personaje_nuevo)
        print("Personaje Agregado con Exito!")
    
    elif opcion == "2":
        if len(personajes) < 2:
            print("No hay mas de 2 personajes para Fusionar...\n")
        else:
            mostrar_personaje(personajes)
            pj_1 = int(input("\nPrimer Personaje a Fusionar: "))
            pj_2 = int(input("Segundo Personaje a Fusionar: "))
            
            if 1 <= pj_1 <= len(personajes) and 1 <= pj_2 <= len(personajes) and pj_1 != pj_2:
                personaje1 = personajes[pj_1 - 1]
                personaje2 = personajes[pj_2 - 1]
                personaje_fusionado = personaje1 + personaje2
                personajes.append(personaje_fusionado)
                print(f"\n!Fusion Exitosa! El nuevo personaje es: {personaje_fusionado}\n")
            else:
                print("Opcion invalida")
    
    elif opcion == "3":
        mostrar_personaje(personajes)
        
    elif opcion == "4":
        print("Saliendo del programa...")
        break
    
    else:
        print("Opcion no valida...\nEliga nuevamente.\n")