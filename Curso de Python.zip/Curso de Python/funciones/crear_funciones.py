
#creando una funcion simple
#def saludar():
#    print("Hola Carlos, que paso wacho, todo bien?")
    
    
#ejecutando la funcion simple
#saludar()


#creando una funcion que tenga parametros
def saludar(nombre, sexo):
    sexo.lower()
    if (sexo == "mujer"):
        adjetivo = "Mi reina"
    elif (sexo == "hombre"):
        adjetivo = "padrino"
    else:
        adjetivo = "miamol"

    print(f"Hola {nombre}, que paso {adjetivo}, todo bien?")
    
saludar("Lili","mujer")
saludar("Albert","hombre")
saludar("Lele","indefinido")

#crear una funcion que nos retorne valores
def crear_contrasena_random(num):
    chars = "abcdefghij"
    num_entero = str(num)
    num = int(num_entero[0])
    c1 = num - 2
    c2 = num
    c3 = num - 5
    contrasena = f"{chars[c1]}{chars[c2]}{chars[c3]}{num*2}"
    return contrasena
    
password = crear_contrasena_random(4)


#Ejercicio mio
respuesta = input("Quieres ver tu contrasena? Y/N: ")
if(respuesta == "Y"):
    print(f"Tu contrasena nueva es: {password}")
else:
    print("A weno")


#crear una funcion que nos retorne multiples valores
def crear_contrasena_random(num):
    chars = "abcdefghij"
    num_entero = str(num)
    num = int(num_entero[0])
    c1 = num - 2
    c2 = num
    c3 = num - 5
    contrasena = f"{chars[c1]}{chars[c2]}{chars[c3]}{num*2}"
    return contrasena,num

#desempaquetando la funcion
password,primer_numero = crear_contrasena_random(4245)

#mostrando los resultados obtenidos y los datos utilizados para obtenerlos
print(f"Tu contrasena nueva es: {password}")
print(f"El numero utlizado para crearla fue: {primer_numero}")


