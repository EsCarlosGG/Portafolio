def calculadora_analogica(opcion):
    if opcion == 'Suma':
        suma1 = int(input("Ingrese el primer numero a sumar: "))
        suma2 = int(input("Ingrese el segundo numero a sumar: "))
        resultado_suma = suma1 + suma2
        return f"""
              {suma1} + {suma2} = {resultado_suma}
              """
    elif opcion == 'Resta':
        resta1 = int(input("Ingrese el primer numero a restar: "))
        resta2 = int(input("Ingrese el segundo numero a restar: "))
        resultado_resta = resta1 - resta2
        return f"""
              {resta1} - {resta2} = {resultado_resta}
              """
    elif opcion == 'Multiplicacion':
        multi1 = int(input("Ingrese el primer numero a multiplicar: "))
        multi2 = int(input("Ingrese el segundo numero a multiplicar: "))
        resultado_multi = multi1 * multi2
        return f"""
              {multi1} * {multi2} = {resultado_multi}
              """
    elif opcion == 'Division':
        divi1 = int(input("Ingrese el primer numero a dividir: "))
        divi2 = int(input("Ingrese el segundo numero a dividir: "))
        resultado_divi = divi1 / divi2
        return f"""
              {divi1} / {divi2} = {resultado_divi}
              """
    else:
        return """
              Opcion no valida.
              Eliga nuevamente: """