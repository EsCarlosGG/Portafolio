#///Enlaces Estaticos////

class Animal:
    def hablar(self):
        return "El animal hace un sonido"

def hacer_hablar(animal: Animal):
    print(animal.hablar())

mi_animal = Animal()
hacer_hablar(mi_animal)

#En este ejemplo, la referencia al método hablar de Animal se resuelve de manera estática
#cuando se llama dentro de la función hacer_hablar, siempre que el argumento sea de tipo Animal.




#///////////Enlaces Dinamicos////////

class Animal:
    def hablar(self):
        return "El animal hace un sonido"

class Perro(Animal):
    def hablar(self):
        return "El perro ladra"

class Gato(Animal):
    def hablar(self):
        return "El gato maúlla"

def hacer_hablar(animal):
    print(animal.hablar())
    

mi_perro = Perro()         #Aqui le estamos especificando al objeto a que clase pertenece
mi_gato = Gato()

hacer_hablar(mi_perro)     #Aqui como el parametro es objeto de Perro(), agarra el metodo hablar de esa clase
hacer_hablar(mi_gato)      #Aqui como el parametro es objeto de Gato(), agarra el metodo hablar de esa clase


#La referencia al método hablar se resuelve en tiempo de ejecución.
#Dependiendo del tipo del objeto (Perro o Gato), se llama al método correspondiente.