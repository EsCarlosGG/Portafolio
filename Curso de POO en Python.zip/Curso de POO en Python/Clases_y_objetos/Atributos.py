

class Celular:
    def __init__(self, marca, modelo, camara):     #Los atributos son: marca, modelo, camara
        self.marca = marca                         #Utilizamos el metodo __init__ como constructor donde igualaremos todos los atributos 
        self.modelo = modelo                       #Utilizamos "self" para estanciar una propiedad y crearla como objeto asi cada objeto tiene atributos propios y ahorramos linea de codigo
        self.camara = camara

                   #Aqui les asignamos los valores
celular1 = Celular("Apple","17pro+/","48MP")
celular2 = Celular("Samsung","S23","48MP")

print(celular2.marca)
