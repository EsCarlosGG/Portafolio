import re

texto = '''Hola master. Estabbb es la cadena 1. Como esta mi capitan
Esta es la linea 2546445 de textoababab.
Y esta es la final (linea 3ababab) definitiva mi capitan'''

#Haciendo una busqueda simple
#resultado = re.search("Hola", texto)                                   #"search" encuentra coincidencias y las devuelve
#resultado_2 = re.findall("esta")                                       #"findall" ecuentra todas las mismas coincidencias que haya y las devuelve

#\d --> busca digitos numericos del 0 - 9
resultado = re.findall(r"\d",texto)                                    #"r" es para decirle que es posible que usemos expresiones regulares

#\D --> busca TODO MENOS digitos numericos del 0 - 9
resultado = re.findall(r"\D",texto)

#\w --> busca caracteres alfanumericos [a-z, A-Z, 0-9,  _ ]
resultado = re.findall(r"\w",texto)

#\W --> busca TODO MENOS caracteres alfanumericos [a-z, A-Z, 0-9,  _ ]
resultado = re.findall(r"\W",texto)

#\s --> busca espacios en blanco --> espacios, tabs, saltos de linea
resultado = re.findall(r"\s",texto)

#\S --> busca TODO MENOS espacios en blanco --> espacios, tabs, saltos de linea
resultado = re.findall(r"\S",texto)

#\. --> busca TODO MENOS saltos en linea
resultado = re.findall(r".",texto)

#\n --> busca saltos en linea
resultado = re.findall(r"\n",texto)

#\ --> cancelar caracteres especiales, cancelando la funcion del punto (\. --> busca TODO MENOS saltos en linea), y buscando puntos directamente
resultado = re.findall(r"\.",texto)

#Armando una candena que busque un numero, seguido de un punto y un espacio
resultado = re.findall(f'\d\.\s',texto)

#^ --> busca el comienzo de una linea (buscando hola al principio de la linea)
resultado = re.findall(f'^Hola', texto, flags=re.M)                                            #Con "flags=re.M" le decimos que sea en multilinea, que con cada "\n" en el texto, lo interprete como una nueva linea

#$ --> busca el final de una linea
resultado = re.findall(r'capitan$', texto, flags=re.M)

#{n} --> busca n cantidad de veces el valor de la izquierda
resultado = re.findall(r'\d{3}\s', texto)

#{n,m} --> almenos n, como maximo m
resultado = re.findall(r'\d{3,4}', texto)

#{n,m} --> almenos n, como maximo m
resultado = re.findall(r'(ab){3}', texto)                                                       #Si encuentras "ab" n cantidad de veces, devuelves 1 ab

#{n} --> almenos n, como maximo m
resultado = re.findall(r'[ab]{3}', texto)                                                       #Los corchetes sirven para decir que {n} se va a aplicar a todo lo que este en []
                                                                                                #Es decir, eso nos devuelve cualquiera de los valores: "aa","ab","ba"."bb"
# | --> busca una cosa y la otra tambien si es que hay
resultado = re.findall(r'\d{3,4}|Hola', texto)  


print(resultado)
#print(resultado_2)