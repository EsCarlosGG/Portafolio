class Consola:
    def __init__(self,marca, año, capacidad):
        self.marca = marca
        self.año = año
        self.capacidad = capacidad
    
    def Prender(self):
        print(f"\nLa {self.marca} se a encendido\n")

while True:
    print("1. Agregar consola")
    print("2. Ver datos de la consola")
    print("3. Prender consola")
    print("4. Salir")
    opcion = input("\nEliga una opcion: ")
    if opcion == "1":
        marca = input("Ingrese la marca: ")
        año = input("Ingrese el año de la consola: ")
        capacidad = input("Capacidad en Gb de la consola: ")
        consola = Consola(marca,año,capacidad)
        
    elif opcion == "2":
        print(f"""
              Datos de la consola\n
              Marca: {consola.marca}
              Año: {consola.año}
              Capacidad en GB: {consola.capacidad}\n""")
        
        
    elif opcion == "3":
        consola.Prender()
        
    elif opcion == "4":
        print("\n\nSaliendo...")
        break
    
    else:
        print("""Opcion no valida\n
              eliga nuevamente.\n""")