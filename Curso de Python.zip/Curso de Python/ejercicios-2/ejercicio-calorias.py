
def contar_calorias():
    edad = int(input("Ingrese su edad: "))
    peso = int(input("Ingrese su peso: "))
    genero = int(input("Ingrese su genero. Hombre = 1.   Mujer = 2. "))
    
    calorias_base = 0
    if genero == 2:
        if edad <= 3:
            calorias_base = ((58.317 * peso) - 31.1)
        elif 3 < edad <= 10:
            calorias_base = ((20.315 * peso) + 485.9)
        elif 10 < edad <= 18:
            calorias_base = ((13.384 * peso) + 692.6) 
        elif 19 < edad <= 30:
            calorias_base = ((14.818 * peso) + 486.6) 
        elif 30 < edad <= 60:
            calorias_base = ((8.126 * peso) + 845.6) 
        elif 60 < edad <= 30:
            calorias_base = ((9.082 * peso) + 658.5) 
            
    elif genero == 1:
        if edad <= 3:
            calorias_base = ((59.512 * peso) - 30.4) 
        elif 3 < edad <= 10:
            calorias_base = ((22.706 * peso) + 504.3) 
        elif 10 < edad <= 18:
            calorias_base = ((17.686 * peso) + 658.2) 
        elif 18 < edad <= 30:
            calorias_base = ((15.057 * peso) + 692.2) 
        elif 30 < edad <= 60:
            calorias_base = ((11.472 * peso) + 873.1) 
        elif 60 < edad <= 30:
            calorias_base = ((11.711 * peso) + 587.7)
    
    actividad = int(input('''Estilo de vida:
                      1. Sedentario
                      2. Ligeramente activo
                      3. Activo o Moderadamente Activo
                      4. Atleta de alto rendimiento
                      :'''))
                    
    if actividad == 1:
        calorias_necesarias = calorias_base * 1.40
    elif actividad == 2:
        calorias_necesarias = calorias_base * 1.69
    elif actividad == 3:
        calorias_necesarias = calorias_base * 1.75
    elif actividad == 4:
        calorias_necesarias = calorias_base * 2.00
    
    
    calorias_totales = f"{(calorias_necesarias * 10 // 10):,}"
    
    print(f"Calorias necesarias: {calorias_totales} kcal")
    
contar_calorias()