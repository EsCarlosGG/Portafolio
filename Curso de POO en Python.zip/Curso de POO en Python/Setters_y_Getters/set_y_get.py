class Persona:
    def __init__(self, nombre, edad):
        self._nombre = nombre
        self._edad = edad
        
        
    def get_nombre(self):
        return self._nombre              #Aqui accede a la pripiedad que esta "privada"
    
    def set_nombre(self, new_nombre):
        self._nombre = new_nombre        #Aqui creamos una funcion que nos pida un nuevo nombre que se asignara a la propiedad = "_nombre"
    


carlos = Persona("Carlos",19)            #Primero creamos el objeto de la clase


nombre = carlos.get_nombre()             #Definimos nombre que almacenara el metodo get_nombre()
print(nombre)                            #e  sta forma tambien es permitida si la prpiedad es muy privada =  "__nombre"




carlos.set_nombre("Pablo")               #Aqui cambiamos el nombre
nombre = carlos.get_nombre()             #Definimos nombre que almacenara el metodo set_nombre()
print(nombre)