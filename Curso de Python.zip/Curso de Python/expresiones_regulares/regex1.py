import re

text = "The quick fox jumps over the lazy dog"

x = re.search("^The.*dog$", text)                        #Con el * le decimos: estamos buscando todo menos saltos en linea, encuentra 0 o mas ocurrencias, si no encuentra ninguna, dejalo pasar
                                                          #si encuentras, devuelvelas.

if x:
    print("SI")
else:
    print("NO")