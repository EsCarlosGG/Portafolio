#si el modulo estuviera adentro de una carpeta en la misma ruta
# import funciones_buenas.saludar as m_saludar

import sys

sys.path.append("c:\\python\\funciones_buenas")

#import saludar as modulo_saludo

#print(modulo_saludo.saludar("Carlos"))