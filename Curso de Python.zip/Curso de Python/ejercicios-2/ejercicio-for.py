
numeros = [3,5,16,4,8,2,7,1,9,6]

contador_pares = 0
suma = 0
#for numero in numeros:
#    suma += numero 

#print(suma)

#maximo = numeros[0]
#for numero in numeros:
  #  if numero > maximo:
 #       maximo = numero

#rint(maximo)

#for numero in numeros:
  #  suma += numero
 #   promedio = suma / len(numeros)
    
#print(promedio)


#for numero in numeros:
#    if numero % 2 == 0:
 #       contador_pares += 1
        
#print(contador_pares)

#cuadrados = 0
#for numero in numeros:
 #   cuadrados = numero**2
  #  print(cuadrados)
  
#numero_filtrar = int(input("Ingrese el numero a filtrar: "))
#numeros_mayores = 0
#for numero in numeros:
 #   if numero > numero_filtrar:
  #      numeros_mayores = numero
   #     print(numeros_mayores)
   


inventario = {
    "manzanas":10,
    "cacahuates":7,
    "aguas":15,
    "platanos":20,
    "naranjas":1
    }


while True:
    print("\nMenu de Inventario")
    print("1. Ver inventario")
    print("2. Agregar producto")
    print("3. Actualizar cantidad de producto")
    print("4. Eliminar producto del inventario")
    print("5. Salir")
    
    opcion = input("Eliga una opcion: ")
    
    if opcion == '1':
        print("""
              
              Opcion 1 seleccionada jaja
              
              """)
        print(" === Inventario actual === ")
        for producto1, cantidad1 in inventario.items():
            print(f"=   {producto1} : {cantidad1}   ")
        
    elif opcion == '2':
        producto = input("Ingrese el nuevo producto: ")
        producto_minus = producto.lower()
        cantidad = int(input("Ingrese la cantidad del nuevo producto: "))
        if producto in inventario:
            inventario[producto_minus] += cantidad
        else:
            inventario[producto_minus] = cantidad
        
        print(f"Producto {producto} agregado con exito!.")
        print(inventario)
        
    elif opcion == '3':
        producto_actualizar = input("ingrese el producto a actualizar: ")
        if producto_actualizar in inventario:
            nueva_cantidad = int(input("Ingrese la nueva cantidad: "))
            inventario[producto_actualizar] = nueva_cantidad
            print(f"Cantidad de {producto_actualizar} actualizado con exito!.")
        else:
            print(f"El producto {producto_actualizar} no se encuentra en el inventario.")

    elif opcion == '4':
        producto_eliminar = input("ingrese el producto a eliminar: ")
        producto_eliminar_minus = producto_eliminar.lower()
        if producto_eliminar_minus in inventario:
            inventario.pop(producto_eliminar_minus)
            print(f"El producto {producto_eliminar_minus} se ha eliminado junto a su cantidad.")
        else:
            print(f"El producto {producto_eliminar_minus} no se encuentra en el inventario.")
            
    elif opcion == '5':
        print("Saliendo del programa")
        break
    
    else:
        print("""Opcion no valida.
              
              Vulva a eligir una opcion:""")